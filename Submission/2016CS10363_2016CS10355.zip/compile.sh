g++ -O3 -std=c++11 -o input input.cpp
g++ -O3 -std=c++11 -o output output.cpp